/*
 * system.h
 *
 *  Created on: 2025. 11. 13.
 *      Author: DELL
 */

#ifndef PORT_H_
#define PORT_H_

/* ===========================
 *     Function
 * =========================== */
void PORT_init(void);
void PORT_IRQHandler(void);
void Port_set(void);
void Port_clear(void);

#endif /* PORT_H_ */

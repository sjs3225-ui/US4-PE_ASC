/*
 * Copyright (c) 2014 - 2016, Freescale Semiconductor, Inc.
 * Copyright (c) 2016 - 2018, NXP.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/*!
 * Description:
 * ================================================================================================================
 * This project is same as the prior one (Clocks), except an interrupt is implemented to handle the timer flag.
 * Instead of software polling the timer flag, the interrupt handler clears the flag and toggles the output.
 * The timeout is again one second using FIRCDIV2_CLK for the LPIT0 timer clock.
 */

#include "S32K116.h"            /* include peripheral declarations for S32K116 */
#include "clocks_and_modes_S32K11x.h"
#include "control.h"
#include "pwm.h"
#include "value.h"
#include "FlexCAN_FD.h"
#include "adc.h"
#include "Lpit.h"
#include "port.h"

unsigned int Reset = 0;
unsigned int Go_to_sleep = 0;
unsigned int Vlps = 0;

//volatile int i;


/* 25.11.18 US4_PE_251118_HEV SW 占쏙옙占쏙옙*/
/* 25.12.16 MOTOR RESET 되는 것 CHECK RESET 수정  */
/* 26.01.14 CAN RX 빠지는거 수정 (RXIMR 개별마스크 및 BUF SIZE 수정) */
/* Sleep - Wakeup 구문 수정*/

void WDOG_disable (void)
{
	WDOG->CNT=0xD928C520; /*Unlock watchdog*/
	WDOG->TOVAL=0x0000FFFF; /*Maximum timeout value*/
	WDOG->CS = 0x00002100; /*Disable watchdog*/
}

void NVIC_init_IRQs (void)
{
	S32_NVIC->ICPR = 1 << PORT_IRQn;	/* IRQ20-LPIT0 ch0: clr any pending IRQ*/
	S32_NVIC->ISER = 1 << PORT_IRQn;	/* IRQ20-LPIT0 ch0: enable IRQ */

	S32_NVIC->ICPR = 1 << LPIT0_IRQn;	/* IRQ20-LPIT0 ch0: clr any pending IRQ*/
	S32_NVIC->ISER = 1 << LPIT0_IRQn;	/* IRQ20-LPIT0 ch0: enable IRQ */
}


void Wake_up(void)
{
	Port_set();
	Vlps = 0;
	door_wakeup=0;
	timer=0;
	sleep=0;
}



void CAN_disable(void)
{

	CAN0->MCR &= ~CAN_MCR_MDIS_MASK;
	CAN0->MCR |= (CAN_MCR_FRZ_MASK | CAN_MCR_HALT_MASK);

	for(j = 0U; !((CAN0->MCR & CAN_MCR_FRZACK_MASK) >> CAN_MCR_FRZACK_SHIFT); j++)
	    {
	        if (j >= 200000U)
	        	break;

	    }

	CAN0->MCR |= CAN_MCR_MDIS_MASK;				// DISABLE

	   for(j = 0U; !((CAN0->MCR & CAN_MCR_LPMACK_MASK) >> CAN_MCR_LPMACK_SHIFT); j++)
	    {
	        if (j >= 200000U)
	        	break;

	    }
}


void CAN_enable(void)
{
    PCC->PCCn[PCC_FlexCAN0_INDEX] |= PCC_PCCn_CGC_MASK;
    CAN0->MCR &= ~CAN_MCR_MDIS_MASK;
    for(j = 0U; (CAN0->MCR & CAN_MCR_LPMACK_MASK) >> CAN_MCR_LPMACK_SHIFT; j++)
    {
        if(j >= 200000U){
        	break;
        }
    }

    CAN0->MCR &= ~(CAN_MCR_FRZ_MASK | CAN_MCR_HALT_MASK);
    for(j = 0U; (CAN0->MCR & CAN_MCR_FRZACK_MASK) >> CAN_MCR_FRZACK_SHIFT; j++)
     {
         if(j >= 200000U){
        	 break;
         }
     }
}

void go_to_sleep(void)
{
	Vlps=1;
	CAN_disable();
    Port_clear();			/*홀센서 전압 OFF*/
    						/*CAN standby mode*/
    						/*MOTOR_DRIVER enable OFF*/
							/*PWM OFF*/

    S32_NVIC->ICER |= 0xFFFFFFFF;


    SMC->PMPROT |= SMC_PMPROT_AVLP_MASK;
    SMC->PMCTRL = (SMC->PMCTRL & ~SMC_PMCTRL_STOPM_MASK) | SMC_PMCTRL_STOPM(0x2u);
    while((SMC->PMCTRL & SMC_PMCTRL_STOPM_MASK) != SMC_PMCTRL_STOPM(0x2u)) {}
    S32_SCB ->SCR |= S32_SCB_SCR_SLEEPDEEP_MASK;

    /* Wait For Interrupt */
    __asm volatile ("wfi");					// VLPS Mode

}

void Sleep(void)
{
	if((ignon==0)&&(door_wakeup==0)){			// Ignition OFF && Event Flag == 0
		sleep=1;

		if(timer >= 10000){
			t=1;
			time_state = 0;
			go_to_sleep();						// Sleep Mode 진입
		}
	}
	else{
		if(Vlps==1){							// Sleep 진입이력 있을 시
			SCG_to_FIRC();						// Main Clock Convert
			CAN_enable();						// CAN enable
			Wake_up();
		}										// Wake Up
												/* Port_set();	 */
	    										/* Vlps = 0;	 */
												/* door_wakeup=0;*/
												/* timer=0;		 */
												/* sleep=0;		 */
		sleep=0;
		timer=0;
		door_wakeup=0;

	}
}


void Skip_Motor_reset(void){

		ESS_Motor_Stop();
		cwmotor=0;
		ccwmotor=0;
		error=2;
		open=0;
		Hallcounter1=234;
		state = 5;


		if (PTA->PDIR & (1 << 1)){
			Step_SW = 1;
		}
		else{
			Step_SW = 0;
		}

		if (PTA->PDIR & (1 << 13)){
			opendoor_ON = 1;
			RrRtDrSw = 1;
			opendoor = 1;
			GearSelect = 1;
			error=1;
			open=1;
		}

		if ((Step_SW == 1) && (opendoor == 1)) {
			Hallcounter = 230;
		}

	RCM->SSRS = 0xffff;
}


void Check_reset(void){


    // SLOC
    if (Reset & (1u << 2)) {
        Skip_Motor_reset();
        return;
    }

    //  SLOL
    if (Reset & (1u << 3)) {
        Skip_Motor_reset();
        return;
    }

    //  SCMU_LOC
    if (Reset & (1u << 4)) {
        Skip_Motor_reset();
        return;
    }

    //  WDOG
    if (Reset & (1u << 5)) {
        Skip_Motor_reset();
        return;
    }

    //  SLOCKUP
    if (Reset & (1u << 9)) {
        Skip_Motor_reset();
        return;
    }

   // SACKERR: VLPS stop error
   if (Reset & (1u << 13)) {
      Skip_Motor_reset();
   }


   Reset = RCM->SSRS;
}



int main(void)
{
	/*!
	 * Initialization:
	 * =======================
	 */
  	  WDOG_disable();	/* ensable WDOG */
	  PORT_init();      /* Configure ports */
	  Port_set();
	  PWM_init();
	  ADC_init();

	  SOSC_init_8MHz(); /* Initialize system oscillator for 8MHz xtal */
	  NormalRUNmode_48MHz();


	  NVIC_init_IRQs();	/* Enable desired interrupts and priorities */
	  FLEXCAN0_init();			// 占쏙옙占쏙옙 open
	  LPIT0_init();     /* Initialize PIT0 for 1 second timeout  */




	/*!
	 * Loop forever:
	 * ========================
	 */

	while(1){
		Check_reset();

//		ESS_Motor_Open();

		LPIT_Handler();
		STEP_SWITCH();
		sidestep();
		Sleep();

		if(time_state != 0)
			time();
		else
			Motor();
	}
}

/*
 * pwm.h
 *
 *  Created on: 2024. 1. 23.
 *      Author: DELL
 */

#ifndef PWM_H_
#define PWM_H_

void PWM_init(void);
#endif /* PWM_H_ */

/*
 * value.h
 *
 *  Created on: 2025. 3. 14.
 *      Author: cts00
 */

#ifndef VALUE_H_
#define VALUE_H_

#include "clocks_and_modes_S32K11x.h"
#include <stdbool.h>
extern unsigned int door_wakeup;
extern unsigned int reset_flag;
extern int a;
extern unsigned int Can_Sleep_Error;
/* Time values */
extern unsigned int Close_time_default;
extern unsigned int Close_time;

/* ADC */
extern int ADC_Results[2];
extern int Voltage_check;
extern int Voltage_real;

/* Status & sensors */
extern unsigned int error1;
extern unsigned int hall;
extern unsigned int DrvDrsw;
extern unsigned int AsstDrSw;
extern unsigned int GearSlctDis;
extern unsigned int GearSelect;

extern unsigned int VehSpd;
extern unsigned int RrLftDrsw;
extern unsigned int RrRtDrSw;
extern unsigned int RrRtDrSw1;

extern unsigned int WHL_Spd_Sum;

extern unsigned int Reset_Flag;
extern unsigned long long j;

/* Hall counters */
extern int Hallcounter;
extern int Hallcounter1;
extern int Hallcounter3;
extern int Hallcounter4;

/* Motor direction */
extern unsigned int CW;
extern unsigned int CCW;
extern unsigned int motor_operate;

/* Switches */
extern unsigned int Step_SW;
extern unsigned int Step_SW_ON;
extern unsigned int closesw;
extern unsigned int opendoor;
extern unsigned int ignon;
extern unsigned int ign;


extern unsigned int opendoor_ON;

/* Voltage / current fails */
extern unsigned int voltagefail;
extern unsigned int currentfail;
extern unsigned int currentfail1;
extern unsigned int currentfail2;
extern unsigned int currenttimer2;
extern unsigned int currentfail3;
extern unsigned int currentfail5;
extern unsigned int currentfail7;
extern unsigned int currentfail8;
extern unsigned int voltagetimer;
extern unsigned int currenttimer;
extern unsigned int currenttimer1;
extern unsigned int currenttimer7;
extern unsigned int currenttimer8;

extern unsigned int step_counter_on;
extern unsigned int step_counter_off;

extern unsigned int ign_counter_off;
extern unsigned int ign_counter_on;

extern unsigned int door_counter_o;
extern unsigned int door_counter_c;



extern unsigned int Gear_timer_1;
extern unsigned int Gear_timer_5;
extern unsigned int Gear_timer_6;
extern unsigned int Gear_timer_7;




/* Sleep & power */
extern unsigned int sleep;
extern unsigned int Current;
extern unsigned int Voltage;

/* Close, open flags */
extern unsigned int close1;
extern unsigned int close2;
extern unsigned int close3;
extern unsigned int close4;
extern unsigned int close5;
extern unsigned int close6;
extern unsigned int close7;
extern unsigned int close8;
extern unsigned int close9;
extern unsigned int close10;

/* Open / motor flags */
extern unsigned int open1;
extern unsigned int open2;
extern unsigned int motor1;
extern unsigned int motor2;

/* Timers */
extern unsigned int timer;
extern unsigned int timer1;
extern unsigned int timer2;

/* Wait flags */
extern unsigned int wait1;
extern unsigned int wait2;
extern unsigned int wait3;
extern unsigned int wait4;
extern unsigned int wait5;
extern unsigned int wait6;

/* Move flags */
extern unsigned int move1;
extern unsigned int move2;
extern unsigned int open;
extern unsigned int cwmotor;
extern unsigned int openmotor;
extern unsigned int closemotor;
extern unsigned int ccwmotor;
extern unsigned int close;

/* States */
extern unsigned int state;
extern unsigned int time_state;
extern unsigned int state1;
extern unsigned int error;
extern unsigned int t;

/* Hallcounter sequences */
extern unsigned int state2;
extern unsigned int Hallcounter5;
extern unsigned int Hallcounter6;
extern unsigned int Hallcounter7;
extern unsigned int Hallcounter8;
extern unsigned int cc;
extern unsigned int cnt;
extern unsigned int herror;

/* Misc */
extern unsigned int hall1;
extern unsigned int tt1;
extern unsigned int tt;

extern int time_cnt1;
extern unsigned int time_cnt2;

extern int OPEN_time;
extern unsigned int start_time;
extern unsigned int stop_time;

extern unsigned int anti_open;
extern unsigned int anti_close;

extern unsigned int stop_open;
extern unsigned int stop_close;



#endif /* VALUE_H_ */

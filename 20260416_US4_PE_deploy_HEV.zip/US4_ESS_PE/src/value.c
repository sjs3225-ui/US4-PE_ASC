/*
 * value.c
 *
 *  Created on: 2025. 11. 13.
 *      Author: DELL
 */
#include "value.h"

int a = 0;
unsigned int Can_Sleep_Error = 0;
/* Time values */
unsigned int Close_time_default = 0;
unsigned int Close_time = 0;

/* ADC */
int ADC_Results[2] = {0,};
int Voltage_check = 0;
int Voltage_real = 0;

/* Status & sensors */
unsigned int error1 = 0;
unsigned int hall = 0;
unsigned int DrvDrsw = 0;
unsigned int AsstDrSw = 0;
unsigned int GearSlctDis = 0;
unsigned int GearSelect = 0;

unsigned int VehSpd = 0;
unsigned int RrLftDrsw = 0;
unsigned int RrRtDrSw = 0;
unsigned int RrRtDrSw1 = 0;



unsigned int WHL_Spd_Sum = 0;


unsigned int reset_flag = 0;
unsigned long long j=0U;

/* Hall counters */
int Hallcounter = 0;
int Hallcounter1 = 0;
int Hallcounter3 = 0;
int Hallcounter4 = 0;

/* Motor direction */
unsigned int CW = 0;
unsigned int CCW = 0;
unsigned int motor_operate = 0;

/* Switches */
unsigned int Step_SW = 0;
unsigned int Step_SW_ON = 0;
unsigned int closesw = 0;
unsigned int opendoor = 0;
unsigned int ignon = 0;
unsigned int door_wakeup = 0;
unsigned int ign = 0;


unsigned int opendoor_ON =0;

/* Voltage / current fails */
unsigned int voltagefail = 0;
unsigned int currentfail = 0;
unsigned int currentfail1 = 0;
unsigned int currentfail2 = 0;
unsigned int currenttimer2 = 0;
unsigned int currentfail3 = 0;
unsigned int currentfail5 = 0;
unsigned int currentfail7 = 0;
unsigned int currentfail8 = 0;
unsigned int voltagetimer = 0;
unsigned int currenttimer = 0;
unsigned int currenttimer1 = 0;
unsigned int currenttimer7 = 0;
unsigned int currenttimer8 = 0;

unsigned int step_counter_on=0;
unsigned int step_counter_off=0;

unsigned int ign_counter_off=0;
unsigned int ign_counter_on=0;

unsigned int door_counter_o=0;
unsigned int door_counter_c=0;


unsigned int Gear_timer_1 = 0;
unsigned int Gear_timer_5 = 0;
unsigned int Gear_timer_6 = 0;
unsigned int Gear_timer_7 = 0;




/* Sleep & power */
unsigned int sleep = 0;
unsigned int Current = 0;
unsigned int Voltage = 0;

/* Close, open flags */
unsigned int close1 = 0;
unsigned int close2 = 0;
unsigned int close3 = 0;
unsigned int close4 = 0;
unsigned int close5 = 0;
unsigned int close6 = 0;
unsigned int close7 = 0;
unsigned int close8 = 0;
unsigned int close9 = 0;
unsigned int close10 = 0;

/* Open / motor flags */
unsigned int open1 = 0;
unsigned int open2 = 0;
unsigned int motor1 = 0;
unsigned int motor2 = 0;

/* Timers */
unsigned int timer = 0;
unsigned int timer1 = 0;
unsigned int timer2 = 0;

/* Wait flags */
unsigned int wait1 = 0;
unsigned int wait2 = 0;
unsigned int wait3 = 0;
unsigned int wait4 = 0;
unsigned int wait5 = 0;
unsigned int wait6 = 0;

/* Move flags */
unsigned int move1 = 0;
unsigned int move2 = 0;
unsigned int open = 0;
unsigned int cwmotor = 0;
unsigned int openmotor = 0;
unsigned int closemotor = 0;
unsigned int ccwmotor = 0;
unsigned int close = 0;

/* States */
unsigned int state = 0;
unsigned int time_state = 0;
unsigned int state1 = 0;
unsigned int error = 0;
unsigned int t = 0;

/* Hallcounter sequences */
unsigned int state2 = 0;
unsigned int Hallcounter5 = 0;
unsigned int Hallcounter6 = 0;
unsigned int Hallcounter7 = 0;
unsigned int Hallcounter8 = 0;
unsigned int cc = 0;
unsigned int cnt = 0;
unsigned int herror = 0;

/* Misc */
unsigned int hall1 = 0;
unsigned int tt1 = 0;
unsigned int tt = 0;

int time_cnt1 = 0;
unsigned int time_cnt2 = 0;

int OPEN_time = 0;
unsigned int start_time = 0;
unsigned int stop_time = 0;

unsigned int anti_open = 0;
unsigned int anti_close = 0;

unsigned int stop_open = 0;
unsigned int stop_close = 0;

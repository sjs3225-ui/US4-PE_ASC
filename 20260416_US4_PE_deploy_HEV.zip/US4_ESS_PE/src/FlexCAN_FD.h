/*
 * adc.h
 *
 *  Created on: 2024. 1. 23.
 *      Author: DELL
 */

#ifndef FLEXCAN_FD_H_
#define FLEXCAN_FD_H_


#define NODE_A /* If using 2 boards as 2 nodes, NODE A & B use different CAN IDs */


void FLEXCAN0_init(void);
void FLEXCAN0_receive_msg(void);



#endif /* FLEXCAN_FD_H_ */

/*
 * adc.h
 *
 *  Created on: 2024. 1. 23.
 *      Author: DELL
 */

#ifndef adc_H_
#define adc_H_
#include "device_registers.h"   /* include peripheral declarations S32K144 */

void convertAdcChan(uint16_t);
void ADC_init(void);
uint8_t adc_complete(void);
uint32_t read_adc_chx(void);


#endif /* ADC_H_ */

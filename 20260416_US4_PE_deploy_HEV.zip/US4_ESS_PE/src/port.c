/*
 * system.c
 *
 *  Created on: 2025. 11. 13.
 *      Author: DELL
 */
#include "port.h"
#include "value.h"
#include "S32K116.h"


void PORT_init (void)
{
	  PCC->PCCn[PCC_PORTA_INDEX]|=PCC_PCCn_CGC_MASK;   /* Enable clock for PORTA */
	  PCC->PCCn[PCC_PORTB_INDEX]|=PCC_PCCn_CGC_MASK;   /* Enable clock for PORTB */
	  PCC->PCCn[PCC_PORTC_INDEX]|=PCC_PCCn_CGC_MASK;   /* Enable clock for PORTC */
	  PCC->PCCn[PCC_PORTD_INDEX]|=PCC_PCCn_CGC_MASK;   /* Enable clock for PORTD */
	  PCC->PCCn[PCC_PORTE_INDEX]|=PCC_PCCn_CGC_MASK;   /* Enable clock for PORTE */


	  PORTE->PCR[4] |= PORT_PCR_MUX(5);   /* Port E4: MUX = ALT5, CAN0_RX */
	  PORTE->PCR[5] |= PORT_PCR_MUX(5); /* Port E5: MUX = ALT5, CAN0_TX */


	  PORTD->PCR[0] = PORT_PCR_MUX(1);
	  PTD->PDDR |= 1<<0;

	  PORTD->PCR[1] = PORT_PCR_MUX(1);
	  PTD->PDDR |= 1<<1;

	  PORTC->PCR[1] = PORT_PCR_MUX(1);         // mtr_sts
	  PTC->PDDR |= 1<<1;

	  PORTB->PCR[4] = PORT_PCR_MUX(1);         // mtr_cw
	  PTB->PDDR |= 1<<4;

	  PORTB->PCR[5] = PORT_PCR_MUX(1);         // mtr_ccw
	  PTB->PDDR |= 1<<5;


	  PTC->PDDR &= ~(1<<3);                    // Hall_sensor1
	      PORTC->PCR[3] = PORT_PCR_MUX(1)							// Sleep �� PORT_PCR_MUX(0)
						|PORT_PCR_PFE_MASK							// WAKE UP �� PORT_PCR_MUX(1)
						|PORT_PCR_IRQC(11);     // either


	  PTA->PDDR &= ~(1<<0);                    // IGN
	      PORTA->PCR[0] = PORT_PCR_MUX(1)
						|PORT_PCR_PFE_MASK
						|PORT_PCR_IRQC(11);     // either


	  PTA->PDDR &= ~(1<<1);                    // Step_SW
	      PORTA->PCR[1] = PORT_PCR_MUX(1)
						|PORT_PCR_PFE_MASK
						|PORT_PCR_IRQC(11);		// either


	  PTA->PDDR &= ~(1<<13);                    // opendoor
	      PORTA->PCR[13] = PORT_PCR_MUX(1)
						|PORT_PCR_PFE_MASK
						|PORT_PCR_IRQC(11);		// either


	  PORTE->PCR[8]|=PORT_PCR_MUX(2);      // mtr_pwm          /* Port E8: MUX = ALT2, FTM0CH6 */

}

void PORT_IRQHandler(void)
{

    /* PORTA interrupt check */

    if (PORTA->ISFR)
    {
        if (PORTA->ISFR & (1 << 13))
        {
            PORTA->ISFR = (1 << 13); // flag clear
            if (PTA->PDIR & (1 << 13)){
            	door_wakeup = 1;
            	opendoor = 1;
            }						// ���� open
            else
            {
            	door_wakeup = 1;
                opendoor = 0;

            }
        }

        if (PORTA->ISFR & (1 << 0))
        {
            PORTA->ISFR = (1 << 0); // flag clear
			if (PTA->PDIR & (1 << 0))
			{
				ign = 0;
			}
			else
			{
				door_wakeup=1;
				ign = 1;
			}
        }

        if (PORTA->ISFR & (1 << 1))
        {
            PORTA->ISFR = (1 << 1); // flag clear
			if (PTA->PDIR & (1 << 1))
			{
				door_wakeup=1;
				Step_SW = 1;
			}
			else
			{
				door_wakeup=1;		 /*sleep ���¿��� ON/OFF �� ��� ����*/
				Step_SW = 0;
			}
        }
    }


    /* PORTC interrupt check */

    if (PORTC->ISFR)
    {
    	 if (PORTC->ISFR & (1 << 3))
    	 {
    		 PORTC->ISFR = (1 << 3); // flag clear
    		 if ((motor_operate == 1 && CW == 1)){
    			 Hallcounter++;
    			 Hallcounter4 = 0;
    		 }
    		 else if((motor_operate == 1 && CW == 0) ){
    			 Hallcounter--;
    			 Hallcounter3 = 0;
    		 }
    	 }
    }
}


void Port_set(void){
	PTC-> PSOR |= 1<<1;  // PTC1 - mtr_sts
	PTD-> PSOR |= 1<<0;  // IOP
	PTD-> PSOR |= 1<<1;  // CAN
	PTE-> PSOR |= 1<<8;  // PWM
}

void Port_clear(void){
	PTC-> PCOR |= 1<<1;  // PTC1 - mtr_sts
	PTD-> PCOR |= 1<<0;  // IOP
	PTD-> PCOR |= 1<<1;  // CAN
	PTE-> PCOR |= 1<<8;


	 step_counter_on=0;
	 step_counter_off=0;

	 ign_counter_off=0;
	 ign_counter_on=0;

	 door_counter_o=0;
	 door_counter_c=0;
}



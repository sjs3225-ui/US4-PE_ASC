/*
 * control.h
 *
 *  Created on: 2024. 1. 23.
 *      Author: DELL
 */

#ifndef control_H_
#define control_H_
#include "device_registers.h"   /* include peripheral declarations S32K116 */

void Motor(void);
void time(void);
void Opertaion_time(void);
void sidestep();
void ESS_Motor_Open();
void ESS_Motor_Close();
void ESS_Motor_Stop();
void STEP_SWITCH();

#endif /* ADC_H_ */

/*
 * interrupt.c


 *
 *  Created on: 2025. 11. 13.
 *      Author: DELL
 */
#include "Lpit.h"
#include "S32K116.h"
#include "FlexCAN_FD.h"
#include "value.h"

unsigned int Lpit_cnt = 0; //
unsigned int ADC_cnt = 0; //ADC_Cnt
volatile unsigned int Timer_flag=0;
void LPIT0_init(void)
{
	/*!
	 * LPIT Clocking:
	 * ==============================
	 */
	PCC->PCCn[PCC_LPIT_INDEX] = PCC_PCCn_PCS(3);    /* Clock Src = 3 (FIRCDIV2_CLK)	*/
	PCC->PCCn[PCC_LPIT_INDEX] |= PCC_PCCn_CGC_MASK; /* Enable clk to LPIT0 regs 		*/

  /*!
   * LPIT Initialization:
   * =====================
   */
  LPIT0->MCR |= LPIT_MCR_M_CEN_MASK;  /* DBG_EN-0: Timer chans stop in Debug mode */
                              	  	  /* DOZE_EN=0: Timer chans are stopped in DOZE mode */
                              	  	  /* SW_RST=0: SW reset does not reset timer chans, regs */
                              	  	  /* M_CEN=1: enable module clk (allows writing other LPIT0 regs) */
  LPIT0->MIER = LPIT_MIER_TIE0_MASK;  /* TIE0=1: Timer Interrupt Enabled for chan0 */
  LPIT0->MIER |= LPIT_MIER_TIE1_MASK;  /* TIE0=1: Timer Interrupt Enabled for chan0 */

  LPIT0->TMR[0].TVAL = 48000;      /* Chan0 Timeout period: 48M clocks */

  LPIT0->TMR[0].TCTRL |= LPIT_TMR_TCTRL_T_EN_MASK;
  	  	  	  	  	  	  	  /* T_EN=1: Timer channel is enabled */
                              /* CHAIN=0: channel chaining is disabled */
                              /* MODE=0: 32 periodic counter mode */
                              /* TSOT=0: Timer decrements immediately based on restart */
                              /* TSOI=0: Timer does not stop after timeout */
                              /* TROT=0 Timer will not reload on trigger */
                              /* TRG_SRC=0: External trigger soruce */
                              /* TRG_SEL=0: Timer chan 0 trigger source is selected*/
}

void LPIT0_IRQHandler(void)
{

#if 1
	 /* Sleep */
	 LPIT0->MSR |= LPIT_MSR_TIF0_MASK;

	 /* ADC_Voltage */
	LPIT0->MSR |= LPIT_MSR_TIF1_MASK; /* Clear LPIT0 timer flag 1 */
	Timer_flag=1;


#else

	 /* Sleep */
	 LPIT0->MSR |= LPIT_MSR_TIF0_MASK;


	 /* TI1_OnInterrupt */

	Lpit_cnt++;
	ADC_cnt++;

	 /* cnt * Voltage_real */
	 time_cnt2++;

	 if(cc==1){
		 cnt++;
	 }else{
		 cnt=0;
	 }

	 /* ADC */
	ADC0_result();

	 if(ADC_cnt == 30){
		 Voltage_real = ((ADC_Results[0]+150)/200);
		 ADC_cnt=0;
	 }


	 /* WIRE - Step_SW Filter */

//	 if(Step_SW==1){
//		 step_counter_off=0;
//
//		 if(step_counter_on<=200){
//			 step_counter_on++;
//		 }else{
//			 step_counter_on=0;
//			 Step_SW_ON=1;
//		 }
//	 }else{
//		 step_counter_on=0;
//
//		 if(step_counter_off<=200){
//			 step_counter_off++;
//		 }else{
//			 step_counter_off=0;
//			 Step_SW_ON=0;
//		 }
//	 }




	 /* CAN - Wheel Speed Filter */

	 if(RrRtDrSw==1){
		 door_counter_c=0;

		 if(door_counter_o<=200){
			 door_counter_o++;
		 }else{
			 door_counter_o=0;
			 RrRtDrSw1=1;
		 }
	 }else{
		 door_counter_o=0;

		 if(door_counter_c<=200){
			 door_counter_c++;
		 }
		 else{
			 door_counter_c=0;
			 RrRtDrSw1=0;
		 }

	 }


	 /* CAN - Wheel Speed Filter */
/*
	 if(WHL_Spd_Sum<=2){
		 WHL_Spd_counter=0;
		 WHL_counter=0;
		 WHL_Spd_total=0;
	 }

	 else{
		 if(WHL_Spd_total<=2)
			 WHL_Spd_counter++;
		 else{
			 WHL_Spd_counter=0;
		 }
	 }


	 if(WHL_Spd_counter>=100){
		 WHL_counter++;
		 WHL_Spd_counter=0;

	 }else{


	 }

	 if(WHL_counter>=3){
		 WHL_Spd_total=3;
		 WHL_counter=0;
		 WHL_Spd_counter=0;
	 }

*/

	 /* CAN - Gear Select Filter */

	switch(GearSlctDis){

	case 0: //P

		Gear_timer_5=0;
		Gear_timer_6=0;
		Gear_timer_7=0;

		if(Gear_timer_1<=200)
			Gear_timer_1++;
		else{
			Gear_timer_1=0;
			GearSelect=1;
		}
		break;

	case 5: //D
		Gear_timer_1=0;
		Gear_timer_6=0;
		Gear_timer_7=0;


		if(Gear_timer_5<=200)
			Gear_timer_5++;
		else{
			Gear_timer_5=0;
			GearSelect=5;
		}
		break;

	case 6: //N
		Gear_timer_1=0;
		Gear_timer_5=0;
		Gear_timer_7=0;

		if(Gear_timer_6<=200)
			Gear_timer_6++;
		else{
			Gear_timer_6=0;
			GearSelect=6;
		}
		break;

	case 7: //R
		Gear_timer_1=0;
		Gear_timer_5=0;
		Gear_timer_6=0;

		if(Gear_timer_7<=200)
			Gear_timer_7++;
		else{
			Gear_timer_7=0;
			GearSelect=7;
		}
		break;
	}








	 /* ADC_Voltage */
	LPIT0->MSR |= LPIT_MSR_TIF1_MASK; /* Clear LPIT0 timer flag 1 */

	if((Voltage<2100)||(Voltage>3950)){     /* ���� �̵��� : 9V ~ 16.3V */
		voltagetimer++;

		if(voltagetimer>500){             		//  + CURRENT(���� ���� �߰�)?
			voltagefail = 1;
		}else{
			voltagefail = 0;
		}

	}else{
		voltagefail = 0;
		voltagetimer = 0;
	}

	 /* Hallcounter time */
	if(PTC->PDIR & (1<<3)){
		Hallcounter4++;
	}else{
		Hallcounter3++;
	}

	 /* ADC_Current */
	 if(Current>1560){  // 7A 1560
		 currenttimer++;
		 currenttimer1++;

		 if(currenttimer1>50){        /*  CUR  : 1A  2A  3A  4A  5A   6A   7A   8A   9A   10A  11A  12A       */
			 currentfail3 = 1;        /* ADC_C : 170 388 638 857 1190 1330 1560 1793 2030 2272 2745 2500      */
		 }							  /*  VOL  : 7V   8V   9V   10V  11V  12V  13V  14V  15V  16V  17V  18V   */
		 if(currenttimer>5000){		  /* ADC_V : 1590 1850 2100 2350 2610 2870 3120 3380 3630 3890 4150 4400   */
			 currentfail=1;
		 }

	 }
	 else{
		 currenttimer = 0;
		 currenttimer1 = 0;
	 }

	 if(Current>2500){ //  12A
		 currenttimer8++;

		 if(currenttimer8>35){
			 currentfail8=1;
		 }

	 }else{
	 currenttimer8=0;
	 }

	 if(Current>2500){  // 12A

		 currenttimer7++;

		 if(currenttimer7>170){
			 currentfail7 = 1;
		 }
	 }
	 else{
		 currenttimer7 = 0;
	 }


	 /* event.c */


	 if(sleep==1){
	 timer++;
	 }else{
	 timer=0;
	 }

	 if(tt1==1){
	 tt++;
	 }else{
	 tt=0;
	 }

	 if(close1==1){
	 close2++;
	 }else{
	 close2=0;
	 }

	 if(close7==1){
	 close8++;
	 }else{
	 close8=0;
	 }


	 if(open1==1){
	 open2++;
	 }else{
	 open2=0;
	 }


	 if(timer2==1){
	 timer1++;
	 }else{
	 timer1=0;
	 }
	 if(close4==1){
	 close3++;
	 }else{
	 close3=0;
	 }

	 if(move1==1){
	 move2++;
	 }else{
	 move2=0;
	 }

	 if(close5==1){
	 close6++;
	 }else{
	 close6=0;
	 }

	 if(close9==1){
	 close10++;
	 }else{
	 close10=0;
	 }


	 if(wait1==1){
	 wait2++;
	 }else{
	 wait2=0;
	 }

	 if(wait3==1){
	 wait4++;
	 }else{
	 wait4=0;
	 }

	 if(wait5==1){
	 wait6++;
	 }else{
	 wait6=0;
	 }


	 switch(state2){
       case 0 :
       if((hall==1)&&(cc=1)){
       state2=1;
       }

       break;
       case 1 :
       if((hall==2)&&(cc=1)){
       Hallcounter5=cnt;
       cnt=0;
       state2=2;
       }

       break;
       case 2 :
       if((hall==1)&&(cc=1)){
       Hallcounter6=cnt;
       cnt=0;
       state2=3;
       }

       break;
       case 3 :
       if((hall==2)&&(cc=1)){
       Hallcounter7=cnt;
       cnt=0;
       state2=4;
       }

       break;

       case 4 :
       if((hall==1)&&(cc=1)){
       Hallcounter8=cnt;
       cnt=0;
       state2=5;

       }

       break;
       case 5 :
      if(Hallcounter5<Hallcounter6) {
        if(Hallcounter6<Hallcounter7) {
         if(Hallcounter7<Hallcounter8) {
          herror=1;
         }
        }
       }else{
        herror=0;
       }
       state2=0;

       break;
  }
#endif

}

void ADC0_result(void)
{
	ADC0->SC1[0]&=~ADC_SC1_ADCH_MASK;
	ADC0->SC1[0] = ADC_SC1_ADCH(5);
	while(((ADC0->SC1[0] & ADC_SC1_COCO_MASK)>>ADC_SC1_COCO_SHIFT)==0){}
	ADC_Results[0]=ADC0->R[0];
	Voltage = ((5000* ADC_Results[0])/0xFFF);



	ADC0->SC1[0]&=~ADC_SC1_ADCH_MASK;
	ADC0->SC1[0] = ADC_SC1_ADCH(4);
	while(((ADC0->SC1[0] & ADC_SC1_COCO_MASK)>>ADC_SC1_COCO_SHIFT)==0){}
	ADC_Results[1]=ADC0->R[0];
	Current = ((5000* ADC_Results[1])/0xFFF);
}

void LPIT_Handler(void){

	if(Timer_flag==1)
	{
		Timer_flag=0;

	 /* TI1_OnInterrupt */

		if (CAN0->IFLAG1 & ((1 << 4) | (1 << 5) | (1 << 6))){
			FLEXCAN0_receive_msg();
		}

		Lpit_cnt++;
		ADC_cnt++;

	 /* cnt * Voltage_real */
	 time_cnt2++;

	 if(cc==1){
		 cnt++;
	 }else{
		 cnt=0;
	 }

	 /* ADC */
	ADC0_result();

	 if(ADC_cnt == 30){
		 Voltage_real = ((ADC_Results[0]+150)/200);
		 ADC_cnt=0;
	 }


	 /* WIRE - Step_SW Filter */



	 if(ign==1){
		 ign_counter_off=0;

		 if(ign_counter_on<=100){
			 ign_counter_on++;
		 }else{
			 ign_counter_on=0;
			 ignon=1;
		 }
	 }else{
		 ign_counter_on=0;

		 if(ign_counter_off<=100){
			 ign_counter_off++;
		 }else{
			 ign_counter_off=0;
			 ignon=0;
		 }
	 }


	 if(opendoor==1){
		 door_counter_c=0;

		 if(door_counter_o<=100){
			 door_counter_o++;
		 }else{
			 door_counter_o=0;
			 opendoor_ON=1;
		 }
	 }
	 else{
		 door_counter_o=0;

		 if(door_counter_c<=100){
			 door_counter_c++;
		 }
		 else{
			 door_counter_c=0;
			 opendoor_ON=0;
		 }
	 }


	 /* CAN - Gear Select Filter */

	switch(GearSlctDis){

	case 0: //P

		Gear_timer_5=0;
		Gear_timer_6=0;
		Gear_timer_7=0;

		if(Gear_timer_1<=100)
			Gear_timer_1++;
		else{
			Gear_timer_1=0;
			GearSelect=1;
		}
		break;

	case 5: //D
		Gear_timer_1=0;
		Gear_timer_6=0;
		Gear_timer_7=0;


		if(Gear_timer_5<=100)
			Gear_timer_5++;
		else{
			Gear_timer_5=0;
			GearSelect=5;
		}
		break;

	case 6: //N
		Gear_timer_1=0;
		Gear_timer_5=0;
		Gear_timer_7=0;

		if(Gear_timer_6<=100)
			Gear_timer_6++;
		else{
			Gear_timer_6=0;
			GearSelect=6;
		}
		break;

	case 7: //R
		Gear_timer_1=0;
		Gear_timer_5=0;
		Gear_timer_6=0;

		if(Gear_timer_7<=100)
			Gear_timer_7++;
		else{
			Gear_timer_7=0;
			GearSelect=7;
		}
		break;
	}


	if((Voltage<2100)||(Voltage>3950)){     /* ���� �̵��� : 9V ~ 16.3V */
		voltagetimer++;

		if(voltagetimer>500){             		//  + CURRENT(���� ���� �߰�)?
			voltagefail = 1;
		}else{
			voltagefail = 0;
		}

	}else{
		voltagefail = 0;
		voltagetimer = 0;
	}

	 /* Hallcounter time */
	if(PTC->PDIR & (1<<3)){
		Hallcounter4++;
	}else{
		Hallcounter3++;
	}

	 /* ADC_Current */
	 if(Current>1560){  // 7A 1560
		 currenttimer++;
		 currenttimer1++;

		 if(currenttimer1>50){        /*  CUR  : 1A  2A  3A  4A  5A   6A   7A   8A   9A   10A  11A  12A       */
			 currentfail3 = 1;        /* ADC_C : 170 388 638 857 1190 1330 1560 1793 2030 2272 2745 2500      */
		 }							  /*  VOL  : 7V   8V   9V   10V  11V  12V  13V  14V  15V  16V  17V  18V   */
		 if(currenttimer>5000){		  /* ADC_V : 1590 1850 2100 2350 2610 2870 3120 3380 3630 3890 4150 4400   */
			 currentfail=1;
		 }

	 }
	 else{
		 currenttimer = 0;
		 currenttimer1 = 0;
	 }

	 if(Current>2500){ //  12A
		 currenttimer8++;

		 if(currenttimer8>35){
			 currentfail8=1;
		 }

	 }else{
	 currenttimer8=0;
	 }

	 if(Current>2500){  // 12A

		 currenttimer7++;

		 if(currenttimer7>170){
			 currentfail7 = 1;
		 }
	 }
	 else{
		 currenttimer7 = 0;
	 }


	 /* event.c */


	 if(sleep==1){
	 timer++;
	 }else{
	 timer=0;
	 }

	 if(tt1==1){
	 tt++;
	 }else{
	 tt=0;
	 }

	 if(close1==1){
	 close2++;
	 }else{
	 close2=0;
	 }

	 if(close7==1){
	 close8++;
	 }else{
	 close8=0;
	 }


	 if(open1==1){
	 open2++;
	 }else{
	 open2=0;
	 }


	 if(timer2==1){
	 timer1++;
	 }else{
	 timer1=0;
	 }
	 if(close4==1){
	 close3++;
	 }else{
	 close3=0;
	 }

	 if(move1==1){
	 move2++;
	 }else{
	 move2=0;
	 }

	 if(close5==1){
	 close6++;
	 }else{
	 close6=0;
	 }

	 if(close9==1){
	 close10++;
	 }else{
	 close10=0;
	 }


	 if(wait1==1){
	 wait2++;
	 }else{
	 wait2=0;
	 }

	 if(wait3==1){
	 wait4++;
	 }else{
	 wait4=0;
	 }

	 if(wait5==1){
	 wait6++;
	 }else{
	 wait6=0;
	 }


	 switch(state2){
       case 0 :
       if((hall==1)&&(cc=1)){
       state2=1;
       }

       break;
       case 1 :
       if((hall==2)&&(cc=1)){
       Hallcounter5=cnt;
       cnt=0;
       state2=2;
       }

       break;
       case 2 :
       if((hall==1)&&(cc=1)){
       Hallcounter6=cnt;
       cnt=0;
       state2=3;
       }

       break;
       case 3 :
       if((hall==2)&&(cc=1)){
       Hallcounter7=cnt;
       cnt=0;
       state2=4;
       }

       break;

       case 4 :
       if((hall==1)&&(cc=1)){
       Hallcounter8=cnt;
       cnt=0;
       state2=5;

       }

       break;
       case 5 :
      if(Hallcounter5<Hallcounter6) {
        if(Hallcounter6<Hallcounter7) {
         if(Hallcounter7<Hallcounter8) {
          herror=1;
         }
        }
       }else{
        herror=0;
       }
       state2=0;

       break;
  }

	}


}

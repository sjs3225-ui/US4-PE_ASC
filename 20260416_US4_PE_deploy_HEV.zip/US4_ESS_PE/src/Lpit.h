/*
 * interrupt.h
 *
 *  Created on: 2025. 11. 13.
 *      Author: DELL
 */

#ifndef LPIT_H_
#define LPIT_H_

/* ===============================
 *   LPIT Public Function
 * =============================== */
void LPIT0_init(void);
void LPIT0_IRQHandler(void);
void ADC0_result(void);
void LPIT_Handler(void);

#endif /* LPIT_H_ */

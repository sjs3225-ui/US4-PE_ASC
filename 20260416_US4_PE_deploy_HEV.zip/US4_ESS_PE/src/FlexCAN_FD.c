/*
 * Copyri//////////////ght (c) 2014 - 2016, Freescale Semiconductor, Inc.
 * Copyright (c) 2016 - 2018, NXP.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "FlexCAN_FD.h"
#include "device_registers.h"	/* include peripheral declarations S32K144 */
#include "value.h"

unsigned int id3e2,id3e2_id;
unsigned int id0x45,id0x45_id;
unsigned int idA0_1,idA0_1_id;
unsigned int idA0_2,idA0_2_id;



uint32_t  RxCODE;              /* Received message buffer code */
uint32_t  RxID;                /* Received message ID */
uint32_t  RxID1;               /* Received message ID */
uint32_t  RxLENGTH;            /* Recieved message number of data bytes */
uint32_t  RxTIMESTAMP;         /* Received message time */

unsigned int RxRrLftDrsw = 0;
volatile unsigned int RxRrRtDrSw=0;
volatile unsigned int RxGearSlctDis=0;

unsigned int RxVehSpd=0;
volatile unsigned int RxWHL_SpdFLVal=0;
volatile unsigned int RxWHL_SpdFRVal=0;
volatile unsigned int RxWHL_SpdRLVal=0;
volatile unsigned int RxWHL_SpdRRVal=0;



unsigned int RxWHL_SpdFLVal1=0;
unsigned int RxWHL_SpdFRVal1=0;
unsigned int RxWHL_SpdRLVal1=0;
unsigned int RxWHL_SpdRRVal1=0;


unsigned int WHL_SpdFLVal=0;
unsigned int WHL_SpdFRVal=0;
unsigned int WHL_SpdRLVal=0;
unsigned int WHL_SpdRRVal=0;

#define MSG_BUF_SIZE 6			/* Msg Buffer Size. (CAN 2.0AB: 2 hdr +  2 data= 4 words) */
#define MSG_BUF_SIZE_EXT 6		/* Msg Buffer Size. (CANFD: 2 hdr +  16 data= 18 words) */


void FLEXCAN0_init(void)
{
  uint32_t   i=0;

  PCC->PCCn[PCC_FlexCAN0_INDEX] |= PCC_PCCn_CGC_MASK; /* CGC=1: enable clock to FlexCAN0 */

  CAN0->MCR |= CAN_MCR_MDIS_MASK;         /* MDIS=1: Disable module before selecting clock 	*/
  CAN0->CTRL1 |= CAN_CTRL1_CLKSRC_MASK;  /* CLKSRC=1: Clock Source = SYS_CLK				*/
  CAN0->MCR &= ~CAN_MCR_MDIS_MASK;        /* MDIS=0; Enable module config. (Sets FRZ, HALT)	*/

  for (j = 0U; !((CAN0->MCR & CAN_MCR_FRZACK_MASK) >> CAN_MCR_FRZACK_SHIFT); j++)
  {
      if (j >= 200000U){
    	  break;
      }
  }
	/*!
	 * Good practice:
	 * ===================================================
	 * wait for FRZACK=1 on freeze mode entry/exit
	 */
	CAN0->CBT = CAN_CBT_BTF_MASK    /* Configure nominal phase: 500 KHz bit time, 48 MHz Sclock */
			|CAN_CBT_EPRESDIV(5)    /* EPRESDIV = Prescaler - 1 = 6 - 1 = 5 */
			|CAN_CBT_EPSEG2(1)		/* EPSEG2 = 1 */
			|CAN_CBT_EPSEG1(4)		/* EPSEG1 = 4 */
			|CAN_CBT_EPROPSEG(7)	/* EPROPSEG = 7 */
			|CAN_CBT_ERJW(1);   	/* ERJW = 1 */


			/* BITRATEn =Fcanclk /( [(1 + (EPSEG1+1) + (EPSEG2+1) + (EPROPSEG + 1)] x (EPRESDIV+1)) */
	// 500k/baud					/* = 48 MHz /( [(1 + ( 4   +1) + ( 1   +1) + (   7    + 1)] x (    5   +1)) */
									/* = 48 MHz /( [1+5+2+8] x 6) = 48 MHz /(16x6) = 500 KHz */

/* Configure data phase: 2 MHz bit time, 48 MHz Sclock */
	CAN0->FDCBT = 0                 /* Configure data phase: 2 MHz bit time, 48 MHz Sclock */
		   |CAN_FDCBT_FPSEG2(2)		/* FPSEG2 = 2    // 2  */
		   |CAN_FDCBT_FPSEG1(2)		/* FPSEG1 = 1    // 2  */
	       |CAN_FDCBT_FPROPSEG(1)	/* FPROPSEG = 6  // 17 */
	       |CAN_FDCBT_FRJW(1)	    /* FRJW = 1      // 1  */
		   |CAN_FDCBT_FPRESDIV(5);	/* FPRESDIV = Prescaler - 1 = = 2 - 1 = 1 */






	CAN0->FDCTRL =	CAN_FDCTRL_FDRATE_MASK	/* Configure bit rate switch, data size, transcv'r delay  */
			|CAN_FDCTRL_MBDSR0(1)	/* SELECTS 16BYTES PER MESSAGE BUFFER */
			|CAN_FDCTRL_TDCEN_MASK	/* MBDSR1: Not applicable */
			|CAN_FDCTRL_TDCOFF(5);   /* MBDSR0=1: Region 0 has 64 bytes data in frame's payload */


  for(i=0; i<128; i++ )
  {   					/* CAN0: clear 32 msg bufs x 4 words/msg buf = 128 words */
    CAN0->RAMn[i] = 0;  /* Clear msg buf word */
  }

     /* ── [수정] 개별 MB 마스크 설정 (IRMQ=1이므로 RXIMR 사용) ───────────── */
      CAN0->RXIMR[4] = 0x1FFC0000;  /* MB4: 표준 ID 전체 비트 체크 */
      CAN0->RXIMR[5] = 0x1FFC0000;  /* MB5: 표준 ID 전체 비트 체크 */
      CAN0->RXIMR[6] = 0x1FFC0000;  /* MB6: 표준 ID 전체 비트 체크 */

      /* ── [수정] MB 설정: word0(CS), word1(ID) 순서 올바르게 ─────────────── */
       /* MB4: ID 0x3E2 */
       CAN0->RAMn[4*MSG_BUF_SIZE + 1] = 0x3E2 << 18; /* ID 먼저 */
       CAN0->RAMn[4*MSG_BUF_SIZE + 0] = 0xC4000000;  /* CODE=EMPTY, RX 활성화 */

       /* [수정] MB5: ID 0x45 (기존 4*로 쓰던것 → 5*로 수정) */
       CAN0->RAMn[5*MSG_BUF_SIZE + 1] = 0x045 << 18;
       CAN0->RAMn[5*MSG_BUF_SIZE + 0] = 0xC4000000;

       /* [수정] MB6: ID 0xA0 (기존 4*로 쓰던것 → 6*로 수정) */
       CAN0->RAMn[6*MSG_BUF_SIZE + 1] = 0x0A0 << 18;
       CAN0->RAMn[6*MSG_BUF_SIZE + 0] = 0xC4000000;


	   CAN0->CTRL2 |= CAN_CTRL2_ISOCANFDEN_MASK;     /* FlexCAN operates using the ISO CAN FD protocol (ISO 11898-1) */

  /* ── [수정] MCR: IRMQ=1(bit16=0x01),FDEN = 0x01 MAXMB=6 ───────────────────────── */
	   CAN0->MCR = 0x00010806;
   /*
		bit16 = 1  → IRMQ ✅
		bit11 = 1  → FDEN ✅
		bit10 = 0  → Reserved ✅
		bit[2:0]=6 → MAXMB=6 ✅
    */

	   for (j = 0U; (CAN0->MCR & CAN_MCR_FRZACK_MASK) >> CAN_MCR_FRZACK_SHIFT; j++)
	   {
	       if(j >= 200000U){
	    	   break;
	       }
	   }

	   /* NOTRDY = 0 될 때까지 대기 (모듈 Ready 확인) */
	   for (j = 0U; (CAN0->MCR & CAN_MCR_NOTRDY_MASK) >> CAN_MCR_NOTRDY_SHIFT; j++)
	   {
	       if(j >= 200000U){
	    	   break;
	       }
	   }
}


void FLEXCAN0_receive_msg(void){
/*! Receive msg from ID 0x556 using msg buffer 4
 *  ============================================
 */

	volatile uint32_t dummy;



	 /* HEV */
	if (CAN0->IFLAG1 & (1 << 4)){
		RxRrRtDrSw = ((CAN0->RAMn[4*MSG_BUF_SIZE + 4]>>30) & 0x03);
		 if(RxRrRtDrSw == 1){
			 RrRtDrSw = 1;
		 }else{
			 RrRtDrSw = 0;
		 }



		 dummy = CAN0->TIMER;       /* MB4 UNLOCK */
		 CAN0->IFLAG1 = (1 << 4);  /* MB4 IFLAG 클리어 */
	}



	/* HEV*/
	if(CAN0->IFLAG1 & (1 << 5)){
		RxGearSlctDis = ((CAN0->RAMn[5*MSG_BUF_SIZE + 3]>>20) & 0x0f);
		GearSlctDis = RxGearSlctDis;



		dummy = CAN0->TIMER;       /* MB5 UNLOCK */
		CAN0->IFLAG1 = (1 << 5);  /* MB5 IFLAG 클리어 */
	}

		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	if(CAN0->IFLAG1 & (1<<6)){
		RxWHL_SpdFLVal = (((CAN0->RAMn[6*MSG_BUF_SIZE + 4]>>24) & 0xff)
						| (((CAN0->RAMn[6*MSG_BUF_SIZE + 4]>>16) & 0x3f)<<8));
		RxWHL_SpdFLVal1 = (RxWHL_SpdFLVal) >>5;
		WHL_SpdFLVal = RxWHL_SpdFLVal1;

		RxWHL_SpdFRVal = (((CAN0->RAMn[6*MSG_BUF_SIZE + 4]>>8) & 0xff)
						| (((CAN0->RAMn[6*MSG_BUF_SIZE + 4]) & 0x3f)<<8));
		RxWHL_SpdFRVal1 = (RxWHL_SpdFRVal) >>5;
		WHL_SpdFRVal = RxWHL_SpdFRVal1;

		RxWHL_SpdRLVal = (((CAN0->RAMn[6*MSG_BUF_SIZE + 5]>>24) & 0xff)
						| (((CAN0->RAMn[6*MSG_BUF_SIZE + 5]>>16) & 0x3f)<<8));
		RxWHL_SpdRLVal1 = (RxWHL_SpdRLVal) >>5;
		WHL_SpdRLVal = RxWHL_SpdRLVal1;

		RxWHL_SpdRRVal = (((CAN0->RAMn[6*MSG_BUF_SIZE + 5]>>8) & 0xff)
						| (((CAN0->RAMn[6*MSG_BUF_SIZE + 5]) & 0x3f)<<8));
		RxWHL_SpdRRVal1 = (RxWHL_SpdRRVal) >>5;
		WHL_SpdRRVal = RxWHL_SpdRRVal1;

	    /* 평균 차속 */
		WHL_Spd_Sum = (WHL_SpdFLVal + WHL_SpdFRVal + WHL_SpdRLVal + WHL_SpdRRVal) >> 2;


		dummy = CAN0->TIMER;       /* MB6 UNLOCK */
	     CAN0->IFLAG1 = (1 << 6);  /* MB6 IFLAG 클리어 */

	 }

	(void)dummy;

}

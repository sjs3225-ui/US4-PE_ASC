/*
 * control.c
 *
 *  Created on: 2024. 1. 23.
 *      Author: DELL
 */

#include "device_registers.h" /* include peripheral declarations S32K116 */

#include <stdlib.h>
#include "FlexCAN_FD.h"
#include "control.h"
#include "Lpit.h"
#include "port.h"
#include "value.h"



/* 25.11.18 US4_PE_251118_HEV SW ����*/
/* 25.12.16 MOTOR ���� opendoor&RrRtDrSw1 ����  */


void sidestep(void)
{
    if(currentfail==1){
    ESS_Motor_Stop();
    currentfail=0;
    }


    /* 26.03.13 - RrRtDrSw1 CAN ID ���� �� VLPS ��� ���� RrRtDrSw1 0���� �ʱ�ȭ �ǳ� Ȯ�� �ʿ�*/
    // -> wake up ���� �� RrRtDrSw1=0�̾��ٰ� ���͸� �� 1�� �ȴٸ� ������ RrRtDrSw1 �� �����.

    if((Step_SW==1)&&(WHL_Spd_Sum==0)&&(RrRtDrSw==1)&&(opendoor_ON==1)&&(voltagefail==0)&&(currentfail==0)&&((GearSelect==1)||(GearSlctDis==9))){     //���ܿ��� 1��
    cwmotor=1;
    ccwmotor=0;
    error=1;
    open=1;
    }


  //  if((Step_SW_ON==1)&&(WHL_Spd_total==0)&&(RrRtDrSw1==0)&&(opendoor==0)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ����2��
    if((Step_SW==1)&&(WHL_Spd_Sum==0)&&(RrRtDrSw==0)&&(opendoor_ON==0)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ����2��
    cwmotor=0;
    ccwmotor=1;
    error=2;
    open=0;
    }


    if((Step_SW==0)&&(WHL_Spd_Sum==0)&&(RrRtDrSw==0)&&(opendoor_ON==0)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ���� 4��
    cwmotor=0;
    ccwmotor=1;
    error=4;
    open=0;
    }


    if((Step_SW==0)&&(WHL_Spd_Sum>=3)&&(RrRtDrSw==1)&&(opendoor_ON==1)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ���� 7��
    cwmotor=0;
    ccwmotor=1;
    error=5;
    open=0;
    }

    if((Step_SW==1)&&(WHL_Spd_Sum>=3)&&(RrRtDrSw==1)&&(opendoor_ON==1)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ���� 8��
    cwmotor=0;
    ccwmotor=1;
    error=6;
    open=0;
    }


    if((Step_SW==0)&&(WHL_Spd_Sum>=3)&&(RrRtDrSw==0)&&(opendoor_ON==0)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ���� 9��
    cwmotor=0;
    ccwmotor=1;
    error=7;
    open=0;
    }

    if((Step_SW==1)&&(WHL_Spd_Sum>=3)&&(RrRtDrSw==0)&&(opendoor_ON==0)&&(voltagefail==0)&&(currentfail==0)){     //����Ŭ���� 10��
    cwmotor=0;
    ccwmotor=1;
    error=8;
    open=0;
    }

           // ���� ����� sw

/*    if((opendoor==1)&&(Step_SW==1)){     //����     //(RrRtDrSw1==1)||
    cwmotor=1;
    ccwmotor=0;
    }
    if((opendoor==0)&&(Step_SW==1)){     //����     // (RrRtDrSw1==0)||
    cwmotor=0;
    ccwmotor=1;
    }
    if((opendoor==0)&&(Step_SW==0)){     //����     // (RrRtDrSw1==0)||
    cwmotor=0;
    ccwmotor=0;
    }*/



}



void ESS_Motor_Open(void) {
      CW=1;
      CCW=0;
      hall = 1;
      PTC-> PSOR |= 1<<1;  // PWM1 mtr_sts
      PTE-> PSOR |= 1<<8;  // PWM6_SetRatio8(0);
      PTB-> PSOR |= 1<<5;  // CCW
      motor_operate = 1;
}

void ESS_Motor_Close(void){
      CW=0;
      CCW=1;
      hall = 2;
      PTC-> PSOR |= 1<<1;  // PWM1 mtr_sts
      PTE-> PSOR |= 1<<8;  // PWM6_SetRatio8(0);
      PTB-> PSOR |= 1<<4;  // CW
      motor_operate = 1;
}

void ESS_Motor_Stop(void){

      CW=0;
      CCW=0;
      hall = 0;
      PTC-> PCOR |= 1<<1;  // PWM1 mtr_sts
      PTE-> PCOR |= 1<<8;  // PWM6_SetRatio8(0);
      PTB-> PCOR |= 1<<5;  // CW
      PTB-> PCOR |= 1<<4;  // CCW
      motor_operate = 0;
}

void STEP_SWITCH(void)
{
   if((PTA->PDIR & (1<<1))){
      Step_SW = 1;
   }
   else{
      Step_SW = 0;
   }
}

static int close_antipinch_counter = 0;
static int close_antipinch_counter1 = 0;


int Voltage_Index[9]={3430, 2800, 2390, 2100, 1860, 1690, 1550};  // Voltage         Index{0,1,2,3,4,5,6}   . {9V, 10V, 11V, 12V, 13V, 14V, 15V}



 void Operation_time(void){                                  // PWM 75% ���� Operation_time
                                                             // ������ ���������� ���� �ð��� �������ϱ� �ð��� ���̸� ����
	 if(Voltage_check == 9) {
		if(Voltage_real==9) Close_time=Close_time_default;
				else if(Voltage_real==10) Close_time=Close_time-(Close_time-Voltage_Index[1]);
				else if(Voltage_real==11) Close_time=Close_time-(Close_time-Voltage_Index[2]);
				else if(Voltage_real==12) Close_time=Close_time-(Close_time-Voltage_Index[3]);
				else if(Voltage_real==13) Close_time=Close_time-(Close_time-Voltage_Index[4]);
				else if(Voltage_real==14) Close_time=Close_time-(Close_time-Voltage_Index[5]);
				else if(Voltage_real==15) Close_time=Close_time-(Close_time-Voltage_Index[6]);
				}
	 else if(Voltage_check == 10) {
		 if(Voltage_real==9) Close_time=Close_time+(Voltage_Index[0]-Close_time);
				else if(Voltage_real==10) Close_time=Close_time_default;
				else if(Voltage_real==11) Close_time=Close_time-(Close_time-Voltage_Index[2]);
				else if(Voltage_real==12) Close_time=Close_time-(Close_time-Voltage_Index[3]);
				else if(Voltage_real==13) Close_time=Close_time-(Close_time-Voltage_Index[4]);
				else if(Voltage_real==14) Close_time=Close_time-(Close_time-Voltage_Index[5]);
				else if(Voltage_real==15) Close_time=Close_time-(Close_time-Voltage_Index[6]);
	   }
	   else if(Voltage_check == 11) {
				if(Voltage_real==9) Close_time=Close_time+(Voltage_Index[0]-Close_time);
				else if(Voltage_real==10) Close_time=Close_time+(Voltage_Index[1]-Close_time);
				else if(Voltage_real==11) Close_time=Close_time_default;
				else if(Voltage_real==12) Close_time=Close_time-(Close_time-Voltage_Index[3]);
				else if(Voltage_real==13) Close_time=Close_time-(Close_time-Voltage_Index[4]);
				else if(Voltage_real==14) Close_time=Close_time-(Close_time-Voltage_Index[5]);
				else if(Voltage_real==15) Close_time=Close_time-(Close_time-Voltage_Index[6]);
	   }
	   else if(Voltage_check == 12) {
				if(Voltage_real==9) Close_time=Close_time+(Voltage_Index[0]-Close_time);
				else if(Voltage_real==10) Close_time=Close_time+(Voltage_Index[1]-Close_time);
				else if(Voltage_real==11) Close_time=Close_time+(Voltage_Index[2]-Close_time);
				else if(Voltage_real==12) Close_time=Close_time_default;
				else if(Voltage_real==13) Close_time=Close_time-(Close_time-Voltage_Index[4]);
				else if(Voltage_real==14) Close_time=Close_time-(Close_time-Voltage_Index[5]);
				else if(Voltage_real==15) Close_time=Close_time-(Close_time-Voltage_Index[6]);
	   }
	   else if(Voltage_check == 13) {
				if(Voltage_real==9) Close_time=Close_time+(Voltage_Index[0]-Close_time);
				else if(Voltage_real==10) Close_time=Close_time+(Voltage_Index[1]-Close_time);
				else if(Voltage_real==11) Close_time=Close_time+(Voltage_Index[2]-Close_time);
				else if(Voltage_real==12) Close_time=Close_time+(Voltage_Index[3]-Close_time);
				else if(Voltage_real==13) Close_time=Close_time_default;
				else if(Voltage_real==14) Close_time=Close_time-(Close_time-Voltage_Index[5]);
				else if(Voltage_real==15) Close_time=Close_time-(Close_time-Voltage_Index[6]);
	   }

	   else if(Voltage_check == 14) {
				if(Voltage_real==9) Close_time=Close_time+(Voltage_Index[0]-Close_time);
				else if(Voltage_real==10) Close_time=Close_time+(Voltage_Index[1]-Close_time);
				else if(Voltage_real==11) Close_time=Close_time+(Voltage_Index[2]-Close_time);
				else if(Voltage_real==12) Close_time=Close_time+(Voltage_Index[3]-Close_time);
				else if(Voltage_real==13) Close_time=Close_time+(Voltage_Index[4]-Close_time);
				else if(Voltage_real==14) Close_time=Close_time_default;
				else if(Voltage_real==15) Close_time=Close_time-(Close_time-Voltage_Index[6]);
	   }

	   else if(Voltage_check == 15) {
				if(Voltage_real==9) Close_time=Close_time+(Voltage_Index[0]-Close_time);
				else if(Voltage_real==10) Close_time=Close_time+(Voltage_Index[1]-Close_time);
				else if(Voltage_real==11) Close_time=Close_time+(Voltage_Index[2]-Close_time);
				else if(Voltage_real==12) Close_time=Close_time+(Voltage_Index[3]-Close_time);
				else if(Voltage_real==13) Close_time=Close_time+(Voltage_Index[4]-Close_time);
				else if(Voltage_real==14) Close_time=Close_time+(Voltage_Index[5]-Close_time);
				else if(Voltage_real==15) Close_time=Close_time_default;
	   }

	   else{
		   Close_time = 1860;         // default : 13V
	   }
 }


void Motor(void){

	switch(state){

	case 0 :			//���Ǿ��¿��� ->1��
		ESS_Motor_Open();
		state = 1;

		break;


	case 1 :			// ����   �ʱ⵿�� ���� ->���� �� ����(Ȧī��Ʈ�ȵ���,���� >7A,12A) ->16����

		open1=1;

		if(((Hallcounter3>=50)||(Hallcounter4>=50))&&(currentfail3==1)){
			open1=0;

			ESS_Motor_Stop();
			Hallcounter= 1000;               ///// 1000
			currentfail3=0;
			currentfail7=0;
			state = 16;
		}

		else if(currentfail7==1){
		   open1=0;

		   ESS_Motor_Stop();
		   Hallcounter=1000;  ///// 1000
		   currentfail3=0;
		   currentfail7=0;
		   state = 16;
		}

            break;


	case 2 :			//�ʱ⵿�� Ŭ���� ->Ŭ���� ��ȣ +vüũ ->3������

		time_cnt2=0;                                    // time_cnt2++, close_time ��� �Ұ��� ?
		Voltage_check = ((ADC_Results[0] + 50)/200);
		ESS_Motor_Close();

		Hallcounter3=0;
		Hallcounter4=0;
		state = 3;

		break;


	case 3 :			//�ʱ⵿�� Ŭ����   ->Ŭ������ ����(Ȧī��Ʈ �ȵ���,����    >7A,12A)->4��

		close1=1;                        //7A

		if(((Hallcounter3>=50)||(Hallcounter4>=50))&&(currentfail3==1)){
			ESS_Motor_Stop();
			currentfail3=0;
			currentfail7=0;
			close1=0;
			Hallcounter1=1000-Hallcounter;

			Close_time=time_cnt2;
			Close_time_default=time_cnt2;
			stop_time = Close_time/100*80;

			state = 4;
		}

		else if(currentfail7==1){       //12A

			ESS_Motor_Stop();
			currentfail3=0;
			currentfail7=0;
			close1=0;
			Hallcounter1=1000-Hallcounter;


			Close_time=time_cnt2;
			Close_time_default=time_cnt2;
			stop_time = Close_time/100*80;

			state = 4;
		}

		break;


	case 16 :			//Ÿ�̸�1  500msüũ ->2������

		timer2=1;      // timer2=1; timer1++;

		if(timer1>500){
			currentfail=0;
			currentfail3=0;
			currentfail7=0;


			state=2;
			timer2=0;
		}

		break;

	case 4 :			//Ÿ�̸�1 500msüũ ->5�����ΰ��� open,Ȧī��Ʈ >250ms->99������

	timer2=1;

	if(timer1>500){
		timer2=0;
		currentfail=0;
		currentfail3=0;
		currentfail7=0;
		Hallcounter=0;


		if(Hallcounter1>250){
			state=99;
		}

		state=5;

		CW=1;
		CCW=0;
	}
	break;


	case 13 :			//Ÿ�̸�1 300msüũ ->5�����ΰ��� close

	timer2=1;          // timer2=1; timer1++;

	if(timer1>300){
		currentfail=0;
		currentfail3=0;
		currentfail7=0;

		state=5;
		timer2=0;
		CW=0	;
		CCW=1;
	}
	break;


	case 5 :			//voltagefail������ �ƴҋ�open�� 7��, close�� 6�� ->������?

		if(!voltagefail){
			error1=0;


			if((cwmotor==1)&&(ccwmotor==0)){   //open
				state = 7;
			}

			if((ccwmotor==1)&&(cwmotor==0)) {   //close
				state = 6;
			}
		}
		break;


	case 6 :			// side_step close //Ȧī���� 15�̻�� close->8��     �ƴϸ�(close����)->5��

		if(Hallcounter>=15){

			ESS_Motor_Close();

			Operation_time();
			stop_time = Close_time/100*80;
			time_cnt2=0;


			Hallcounter3=0;
			Hallcounter4=0;
			state = 8;
		}
		else{
			state = 5;
		}
		break;


	case 7 :			// side_step open     //Ȧī���� 234-15 �����Ͻ� open->9�� �ƴϸ�(open����)->5��

		if(Hallcounter<=(Hallcounter1-15)){

		  ESS_Motor_Open();

		  Operation_time();
		  stop_time = Close_time/100*80;
		  time_cnt2=0;

		  Hallcounter3=0;
		  Hallcounter4=0;
		  close_antipinch_counter=0;

		  state = 9;
		}
		else{
			state = 5;
		}
		break;


	case 8 :			// ����ġ�������¿��� open��ȣ ->���� state 13, ��Ƽ��ġ���� -> close state20

		if((Step_SW==1)&&(open==1)&&(close==0)){     // Close ���� �� Open ��ȣ
			ESS_Motor_Stop();

			closemotor=1;
			openmotor=1;
			state =13 ;		// STATE 8 �� 13 �� 5 �� 7 �� 9
			currentfail3=0;
			currentfail7=0;
		}

		if(((Hallcounter3>=30)||(Hallcounter4>=30))&&(Hallcounter>=15)&&(currentfail3==1)&&(herror==1)){	// anti-pinch
			ESS_Motor_Close();

			currentfail3=0;
			currentfail7=0;
			state = 20;
		}



	   if((currentfail3==1)&&((Hallcounter3>=30)||(Hallcounter4>=30))){					// Normal CLOSE clear
		  ESS_Motor_Stop();
		  close=0;
		  openmotor=0;
		  currentfail3=0;
		  currentfail7=0;

		  state = 4;
		  timer2=0;
	   }
	   else if(currentfail7==1){																			// anti-pinch
		  ESS_Motor_Close();
		  currentfail3=0;
		  currentfail7=0;
		  state = 20;
	   }
	   break;

	case 9 :			//Ȧī��Ʈ������Ƽ��ġ��  ����->state 10,����ġ������ ��������->����state6,������½� ����-?state13,���������state10 Ȧī���ͳʹ������� state99

		if((Hallcounter3>=10000)||(Hallcounter4>=10000)){
			ESS_Motor_Stop();
			state = 10;
		}


	   if(((Hallcounter3>=30)||(Hallcounter4>=30))&&(Hallcounter<Hallcounter1-15)&&(Hallcounter>15)&&(currentfail3==1)&&(herror==1)){ // anti-pinch
		   ESS_Motor_Stop();
		   currentfail3=0;
		   currentfail7=0;
		   close=1;
		   error1=3;
		   state = 10;
		}


		if((Step_SW==1)&&((RrRtDrSw==0)&&(opendoor_ON==0))){     // OPEN ���� �� CLOSE ��ȣ
			ESS_Motor_Stop();

			closemotor=1;
			openmotor=1;
			currentfail=0;
			currentfail3=0;
			currentfail7=0;

			state = 6;
		}

		if((Hallcounter>=Hallcounter1-15)&&(currentfail3==1)&&((Hallcounter3>=30)||(Hallcounter4>=30))) {	// Normal OPEN clear
			ESS_Motor_Stop();
			closemotor=0;
			openmotor=0;

			currentfail3=0;
			currentfail7=0;
			state = 13;
			timer2=0;
		}
		else if(currentfail7==1){
			ESS_Motor_Stop();
			currentfail3=0;
			currentfail7=0;

			state = 10;
		}
		else if(Hallcounter >= Hallcounter1+15){
			ESS_Motor_Stop();
			currentfail3=0;
			currentfail7=0;

			state=99;
		}
		break;


	case 10 :			//->state 11��

		Hallcounter3=0;
		Hallcounter4=0;
		currentfail=0;
		currentfail3=0;
		currentfail7=0;
		tt1=1;

		state = 11;

		break;


	case 11 :			//����������or����3�̻��϶� ->6

		if(((RrRtDrSw==0)&&(opendoor_ON==0))||(WHL_Spd_Sum>=3)){
			state = 6; // motor_close
			}
		break;


	case 19 :			//    ->state 21��

		close7=1;         // close7=1; close8++;

		if(close8>100){
			currentfail=0;
			currentfail3=0;
			currentfail7=0;
			close7=0;

			Hallcounter3=0;
			Hallcounter4=0;
			state = 21;
		}
		break;


	case 20 :			//motor ����   state->19, state->4, state->25

		close4=1;          // close4=1; close3++;

		if(close3>2000 && close_antipinch_counter<=1){
			close4=0;
			ESS_Motor_Stop();
			currentfail3=0;
			currentfail7=0;
			close_antipinch_counter++;
			state = 19;
		}

		if((currentfail3==1)&&((Hallcounter3>=30)||(Hallcounter4>=30))){
			ESS_Motor_Stop();
			close=0;
			openmotor=0;
			currentfail3=0;
			currentfail7=0;
			close4=0;
			close_antipinch_counter=0;
			state = 4;
			timer2=0;
		}

		else if((close_antipinch_counter1>1 || close_antipinch_counter>1)){
			ESS_Motor_Stop();
			close4=0;
			currentfail=0;
			currentfail3=0;
			currentfail7=0;

			if((Step_SW==1)&&(open==1)&&(close==0)){
				close_antipinch_counter=0;
				close_antipinch_counter1=0;
				state = 25;
			}
		}

	   else if(cwmotor){
		  close_antipinch_counter=0;
		  close_antipinch_counter1=0;
		  state = 25;
	   }
		break;


	case 21 :			//open��  ->state25, �ټӵ�3>=�Ͻ� state6

		close4=0;
		if((open==1)&&(close==0)){
			close_antipinch_counter=0;
			close_antipinch_counter1=0;
			state = 25;
		}

		if(WHL_Spd_Sum>=3){
			currentfail3=0;
			currentfail7=0;
			state = 6;
		}
		break;


	case 22 :			//->state23

		Hallcounter3=0;
		Hallcounter4=0;
		tt1=1;
		state = 23;
	break;


	case 23 :			//�������� ����ġ�½� state7

		if(((RrRtDrSw==1)&&(opendoor_ON==1))&&(Step_SW==1)){
			state = 7;  /// ESS_MOTOR_OPEN
		}
		break;


	case 25 :			//���½�ȣ->state9

		timer2=1;

		if(timer1>100){
			currentfail=0;
			currentfail3=0;
			currentfail7=0;
			timer2=0;

			ESS_Motor_Open();

			Hallcounter3=0;
			Hallcounter4=0;
			state = 9;

			CW=1;
			CCW=0;
		}
		break;


	case 99 :			//time state��

		time_state=4;
		time();

		break;

	}

}

void time(void){


	switch(time_state){
	case 4 :            //open ��ȣ �� ->state7

	timer2=1;

	if(timer1>100){
	currentfail=0;
	currentfail3=0;
	currentfail7=0;
	Hallcounter=0;
	time_state=7;
	timer2=0;
	CW=1;
	CCW=0;
	}
	break;


	case 13 :           //close ��ȣ �� -> state6

	timer2=1;

	if(timer1>100){
		currentfail=0;
		currentfail3=0;
		currentfail7=0;

		time_state=6;

		timer2=0;
		CW=0;
		CCW=1;
	}
	break;


	case 6 :            //close ��ȣ �� ->state8

	timer2=1;

	if(timer1>200){
		currentfail=0;
		currentfail3=0;
		currentfail7=0;
		error1=0;

		if(ccwmotor==1){
			Operation_time();
			stop_time = Close_time/100*80;


			time_cnt2=0;
			ESS_Motor_Close();
			Hallcounter3=0;
			Hallcounter4=0;
			timer2=0;
			time_state = 8;
		}
	}
	break;

	case 7 :            //open��ȣ ��  ->state9

	timer2=1;

	if(timer1>200){
	currentfail=0;
	currentfail3=0;
	currentfail7=0;

	error1=0;

	if(cwmotor==1){

	Operation_time();
	stop_time = Close_time/100*80;

	time_cnt2=0;
	ESS_Motor_Open();
	Hallcounter3=0;
	Hallcounter4=0;
	timer2=0;
	time_state = 9;
	}

	}


	break;

	case 8 :            // CLOSE ������ȣ ->�������� ������ state 29, ������ state 20, �ð��ʰ��� state 4,����12a�ʰ��� state20

		if(cwmotor){     //������ ���� ����ġ ��ȣ ���� ��ȣ

		anti_close= time_cnt2;
		time_cnt2=0;

		ESS_Motor_Stop();

		closemotor=1;
		openmotor=1;
		currentfail3=0;
		currentfail7=0;

		time_state = 29;



					   }
	   //---------------
	   //Anti-pinch
	   //-------------
	   if(((Hallcounter3>=30)||(Hallcounter4>=30))&&(time_cnt2<stop_time)&&(currentfail3==1))
	   {

		stop_close= time_cnt2;
		time_cnt2=0;

		 ESS_Motor_Stop();
		  currentfail3=0;
		  currentfail7=0;

		time_state = 20;

	   }

	   //------------
	   //close-range
	   //-------------
	   if((time_cnt2>=stop_time)&&(currentfail3==1)&&((Hallcounter3>=30)||(Hallcounter4>=30))) {

		ESS_Motor_Stop();
		close=0;
		openmotor=0;
		currentfail3=0;
		currentfail7=0;
		timer2=0;

		time_state = 4;

					   }
	//over Current
	else if(currentfail7){

	stop_close= time_cnt2;
	time_cnt2=0;

	ESS_Motor_Stop();

	currentfail3=0;
	currentfail7=0;
	time_state = 20;
	}



	break;

	case 9 :            // OPEN  ������ȣ->�������� ������ state 28, ������ state26, �ð��ʰ��� state13,���� 12a�ʰ��� sate26

	if((Hallcounter3>=10000)||(Hallcounter4>=10000)){
	ESS_Motor_Stop();
	time_state = 10;
	}

	//---------------
	//Anti-pinch
	//-------------
	if(((Hallcounter3>=30)||(Hallcounter4>=30))&&(time_cnt2<stop_time)&&(currentfail3==1)){


	stop_open= time_cnt2;
	time_cnt2=0;

	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;

	close=1;
	error1=3;
	time_state = 26;
	}


	if((Step_SW==1)&&((RrRtDrSw==0)&&(opendoor_ON==0))){     // ���� ���� ���� ��ȣ?

	anti_open = time_cnt2;
	time_cnt2=0;

	ESS_Motor_Stop();

	closemotor=1;
	openmotor=1;
	currentfail=0;
	currentfail3=0;
	currentfail7=0;

	Hallcounter3=0;
	Hallcounter4=0;

	time_state = 28;

					   }

	//------------
	//open-range
	//------------
	if((time_cnt2>=stop_time)&&(currentfail3==1)&&((Hallcounter3>=30)||(Hallcounter4>=30))) {

	ESS_Motor_Stop();
	closemotor=0;
	openmotor=0;

	currentfail3=0;
	currentfail7=0;
	Hallcounter3=0;
	Hallcounter4=0;
	timer2=0;

	time_state = 13;

	}


	 else if(currentfail7){

	stop_open= time_cnt2;
	time_cnt2=0;

	ESS_Motor_Stop();

	currentfail3=0;
	currentfail7=0;

	close=1;
	error1=3;
	time_state = 26;
	  }


	   break;

	case 10 :			// Hallcounter3, Hallcounter4 <= 10000�� �� (���� �Ұ�)
	Hallcounter3=0;
	Hallcounter4=0;
	tt1=1;
	time_state = 11;

	break;

	case 11 :           //������or����ġ0or���ǵ�3�̻� ->state6


		if(((RrRtDrSw==0)&&(opendoor_ON==0))||(Step_SW==0)||(WHL_Spd_Sum>=3)){
		time_state = 6;
		}

	   break;

	case 19 :			//100ms����� state->21

	wait1=1;

	if(wait2>100){
	currentfail=0;
	currentfail3=0;
	currentfail7=0;
	wait1=0;

	Hallcounter3=0;
	Hallcounter4=0;
	time_state = 21;

	}

	break;

	case 20 :			// (overcurrent) 12A �߻� �� case 20���� 100ms ���, open�� state30,close�� state31 cw ccw ���� �� state �̵�

	wait3=1;
	if(wait4>100){


	if(cwmotor==1){
	wait3=0;
	currentfail3=0;
	currentfail7=0;
	time_cnt2=0;
	ESS_Motor_Open();
	close_antipinch_counter=0;
	Hallcounter3=0;
	Hallcounter4=0;
	timer2=0;
	time_state = 30;
	}


	else if(ccwmotor==1){
	wait3=0;
	currentfail3=0;
	currentfail7=0;
	time_cnt2=0;
	ESS_Motor_Close();
	Hallcounter3=0;
	Hallcounter4=0;
	timer2=0;
	time_state = 31;

	}


	}

	break;

	case 21 :			//open�� state 7, �ӵ�>=3 sate20
	close4=0;
	if(cwmotor){
	currentfail3=0;
	currentfail7=0;
	close_antipinch_counter=0;
	time_state = 7;
	}
	if(WHL_Spd_Sum>=3){
	currentfail3=0;
	currentfail7=0;
	time_state = 20;
	}
	break;


	/*
	case 22 :

						Hallcounter3=0;
						Hallcounter4=0;
						tt1=1;
						time_state = 23;
						break;

						case 23 :

						if(((RrRtDrSw1==1)&&(opendoor==1))&&(Step_SW_ON==1)){
						time_state = 7;
						}

					   break;
	*/

	case 24 :			//���� (����>=7AandȦī��Ʈ30ms����)or12A�̻�->state7

	close4=1;
	if(close3>anti_open){

	if(currentfail3==1&&((Hallcounter3>=30)||(Hallcounter4>=30))){
	close4=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 7;
	}

	else if(currentfail7){
	close4=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 7;
	}


	}

	break;

	case 25 :			//����(����>=7AandȦī��Ʈ30ms����)or12A�̻�->state6

	close5=1;
	if(close6>anti_close){

	if((currentfail3==1)&&((Hallcounter3>=30)||(Hallcounter4>=30))){
	close5=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 6;
	}

	else if(currentfail7){
	close5=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 6;
	}



	}
	break;


	case 26 :			//300ms����� close->state 27
	close4=1;
	if(close3>300){
	close4=0;
	currentfail3=0;
	currentfail7=0;

	if(ccwmotor==1){

	time_cnt2=0;
	ESS_Motor_Close();
	Hallcounter3=0;
	Hallcounter4=0;
	time_state = 27;
	}
	}


	break;

	case 27 :			//7A�̻�andȦī��Ʈ 30ms���� or���� 12a�̻� ->������ state7

	close7=1;
	if(close8>stop_open){
	if(currentfail3==1&&((Hallcounter3>=30)||(Hallcounter4>=30))){
	close7=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 7;
	}
	else if(currentfail7){
	close7=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 7;
	}

	}
	break;

	case 28 :			//300ms��� ->close->state24

	timer2=1;

	if(timer1>300){
	currentfail=0;
	currentfail3=0;
	currentfail7=0;
	timer2=0;

	ESS_Motor_Close();
	time_state=24;
	}
	break;

	case 29 :			//300ms��� ->open->state25

	timer2=1;

	if(timer1>300){
	currentfail=0;
	currentfail3=0;
	currentfail7=0;
	timer2=0;

	ESS_Motor_Open();
	// ESS_Motor_Stop();
	time_state=25;
	}
	break;

	case 30 :			//(����>=7Aand Ȧī��Ʈ 30ms���� )or����>=12A ����->state6

	close9=1;
	if(close10>stop_close){

	if(currentfail3==1&&((Hallcounter3>=30)||(Hallcounter4>=30))){
	close9=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 6;
	}
	else if(currentfail7){

	close9=0;
	ESS_Motor_Stop();
	currentfail3=0;
	currentfail7=0;
	time_state = 6;
	}


	}
	break;


	case 31 :			//2000ms�ʰ� and ��Ƽx ->����->state19 ,or ����->state7
			wait5=1;
			if(wait6>2000 && close_antipinch_counter<1){

			wait5=0;
			ESS_Motor_Stop();
			currentfail3=0;
			currentfail7=0;
			close_antipinch_counter++;
			time_state = 19;

			}


		else if((close_antipinch_counter>=1) && time_cnt2>=stop_time){

			 ESS_Motor_Stop();
			  wait5=0;
			  currentfail=0;
			  currentfail3=0;
			  currentfail7=0;

			if(cwmotor){
				wait5=0;
				close_antipinch_counter=0;
				time_state = 7;
			  }


		}
		else if(cwmotor==1){

		wait5=0;
		currentfail3=0;
		currentfail7=0;
		close_antipinch_counter=0;
		time_state = 7;

		}
		break;
	   }
}

src/port.o: ../src/port.c \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/lib_c99.prefix \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/common.prefix \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewl_c_version.h \
 ../src/port.h ../src/value.h ../src/clocks_and_modes_S32K11x.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/stdbool.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ansi_parms.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewlGlobals.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/arm/ansi_prefix.ARM.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/os_enum.h \
 C:/Users/cts00/Desktop/program/2.US4_ESS_PE/6.SW\ deploy/260409_SW_final_deploy/20260416_US4_PE_deploy_HEV/US4_ESS_PE/include/S32K116.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/stdint.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/cstdint \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/limits_api.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewl_lib_ext1.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/wchar_t.h

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/lib_c99.prefix:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/common.prefix:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewl_c_version.h:

../src/port.h:

../src/value.h:

../src/clocks_and_modes_S32K11x.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/stdbool.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ansi_parms.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewlGlobals.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/arm/ansi_prefix.ARM.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/os_enum.h:

C:/Users/cts00/Desktop/program/2.US4_ESS_PE/6.SW\ deploy/260409_SW_final_deploy/20260416_US4_PE_deploy_HEV/US4_ESS_PE/include/S32K116.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/stdint.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/cstdint:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/limits_api.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewl_lib_ext1.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/wchar_t.h:

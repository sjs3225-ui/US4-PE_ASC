################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/FlexCAN_FD.c \
../src/Lpit.c \
../src/adc.c \
../src/clocks_and_modes_S32K11x.c \
../src/control.c \
../src/main.c \
../src/port.c \
../src/pwm.c \
../src/value.c 

OBJS += \
./src/FlexCAN_FD.o \
./src/Lpit.o \
./src/adc.o \
./src/clocks_and_modes_S32K11x.o \
./src/control.o \
./src/main.o \
./src/port.o \
./src/pwm.o \
./src/value.o 

C_DEPS += \
./src/FlexCAN_FD.d \
./src/Lpit.d \
./src/adc.d \
./src/clocks_and_modes_S32K11x.d \
./src/control.d \
./src/main.d \
./src/port.d \
./src/pwm.d \
./src/value.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/FlexCAN_FD.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '



src/value.o: ../src/value.c \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/lib_c99.prefix \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/common.prefix \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewl_c_version.h \
 ../src/value.h ../src/clocks_and_modes_S32K11x.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/stdbool.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ansi_parms.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewlGlobals.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/arm/ansi_prefix.ARM.h \
 C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/os_enum.h

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/lib_c99.prefix:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/common.prefix:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewl_c_version.h:

../src/value.h:

../src/clocks_and_modes_S32K11x.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/stdbool.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ansi_parms.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/ewlGlobals.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/arm/ansi_prefix.ARM.h:

C:/NXP/S32DS_ARM_v2.2/S32DS/build_tools/gcc_v4.9/arm_ewl2/EWL_C/include/os_enum.h:
